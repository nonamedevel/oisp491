function test1() {
    const a = 5
    const b = 60
    console.log(a + b)
    const result = document.querySelector('#result')
    result.textContent = a + b
}

function test() {
    const input1 = document.createElement("input")
    document.body.append(input1)
    const input2 = document.createElement("input")
    document.body.append(input2)
    const button = document.createElement("button")
    button.textContent = 'sum'
    document.body.append(button)
    const result = document.querySelector(".result")
    
    button.addEventListener('click', function() {
        let sum = Number(input1.value) + Number(input2.value)
        result.textContent = sum
    })
}

test()
