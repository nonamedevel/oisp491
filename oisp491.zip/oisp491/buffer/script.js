const { Buffer } = require('node:buffer')

function test1() {
    const buf = Buffer.alloc(5)
    console.log(buf)
}

function test1() {
    const buf = Buffer.from('abc')
    // const buf = Buffer.from('абв')
    console.log(buf)
}

function test() {
    const buf = Buffer.from('abc')
    console.log(buf)
    buf[0] = buf[0] - 32
    buf[1] = buf[1] - 32
    buf[2] = buf[2] - 32
    console.log(buf)
    console.log(buf.toString())
}

test()
