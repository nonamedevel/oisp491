function test() {
    const num1 = 500
    const num2 = 0
    if (num1 > 0 && num2 > 0) {
        console.log('$$$$$$$$$$')
    } else {
        console.log('**********')
    }
}

test()
