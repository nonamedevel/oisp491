function test() {
    let color = 'black'
    // let color = 'white'

    if (color === 'black') {
        color = 'white'
    } else {
        color = 'black'
    }
    
    console.log(color)
}

test()
