const http = require('http')

http.get('http://localhost:8001/', function(res) {
    console.log(res.statusCode)
    // res.setEncoding('utf8')
    let rawData = ''
    res.on('data', function(chunk) { 
        rawData += chunk 
    })
    res.on('end', function() {
        try {
            const parsedData = JSON.parse(rawData)
            console.log(parsedData)
        } catch (e) {
            console.error(e.message)
        }
    })
}).on('error', function(e) {
    console.error(`Got error: ${e.message}`)
})
