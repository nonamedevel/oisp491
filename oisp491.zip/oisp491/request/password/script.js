/*
    Homework: serve a client only if it provides a valid password
    Keep things as simple a possible
*/