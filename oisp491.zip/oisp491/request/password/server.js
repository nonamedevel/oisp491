/*
    Homework: serve a client only if it provides a valid password
    Keep things as simple a possible
*/
const http = require('http')

const server = http.createServer(function(req, res) {
    // console.log(req.url)
    const url = new URL('http://localhost' + req.url)
    const password = url.searchParams.get('password')
    if (password && password === '123') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            num: 123,
        }));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('404 Not found');
    }
});

server.listen(8001); 