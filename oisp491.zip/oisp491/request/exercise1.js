const https = require('https')
const fs = require('fs')

class ImageDownloader {
    constructor(options) {
        this.url = options.url
        https.get(this.url, function(res) {
            console.log(res.statusCode)
            // const bufSize = Number(res.headers['content-length'])
            // console.log(bufSize)
            const bufArray = []
            res.on('data', function(chunk) {
                // console.log(chunk.length)
                bufArray.push(chunk)
            })
            res.on('end', function() {
                const outPath = 'C:/oisp491/request/example_file.png'
                fs.writeFile(outPath, Buffer.concat(bufArray), function(err) {
                    if (err) throw err
                    console.log('done')
                })
            })
        }).on('error', function(err) {
            console.error(`Got error: ${err.message}`)
        })
    }
}
const test1 = new ImageDownloader({
    // url: "https://cdn-icons-png.flaticon.com/128/17734/17734809.png",
    url: "https://cdn-icons-png.flaticon.com/128/17734/17734780.png"
})
