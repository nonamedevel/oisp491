const https = require('https')
const fs = require('fs')

const url = 'https://brics.life'
// const url = 'https://brics.life/wp-content/uploads/2022/09/brics-college-icon.svg'
https.get(url, function(res) {
    console.log(res.statusCode)
    let rawData = ''
    res.on('data', function(chunk) { 
        rawData += chunk 
    })
    res.on('end', function() {
        const outPath = 'C:/oisp491/request/brics_life.html'
        fs.writeFile(outPath, rawData, function(err) {
            if (err) throw err
            console.log('done')
        })
    })
}).on('error', function(err) {
    console.error(`Got error: ${err.message}`)
})
