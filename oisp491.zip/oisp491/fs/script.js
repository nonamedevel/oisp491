const fs = require('fs')

function test1() {
    const data = 'I do not know what to write here.'
    fs.writeFile('D:/oisp491/fs/example.txt', data, function(err) {
        if (err) throw err
    })
}

function test() {
    fs.readFile('D:/oisp491/fs/example.txt', 'utf8', function(err, data) {
        if (err) throw err
        console.log(data)
    })
}

test()
