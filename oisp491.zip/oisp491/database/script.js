/*
    Relational database
    relation - отношение, связь
    fk - foreign key

    CRUD - create, read, update, delete
*/
