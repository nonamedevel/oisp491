function test1() {
    setTimeout(function() {
        console.log(444)
    }, 3000)
}

function test() {
    setInterval(function() {
        console.log(444)
    }, 1000)
}

test()
