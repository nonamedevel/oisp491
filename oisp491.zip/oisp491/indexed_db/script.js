function test1() {
    const req = indexedDB.open('example')
    // console.log(req)
    req.onsuccess = function(event) {
        // console.log(event.target === req)
        // console.log(req.result)
    }
    req.onerror = function(err) {
        console.log(err)
    }
}

function test1() {
    const req = indexedDB.open('example')
    req.onupgradeneeded = function() {
        console.log('upgradeneeded')
    }
}

async function test1() {
    console.log(await indexedDB.databases())
}


async function test1() {
    const req = indexedDB.deleteDatabase('4364788')
    req.onsuccess = function(event) {
        console.log('success')
    }
    req.onerror = function(err) {
        console.log(err)
    }
}
async function test1() {
    const arr = await indexedDB.databases()
    for (const obj of arr) {
        indexedDB.deleteDatabase(obj.name)
    } 
}

test()
