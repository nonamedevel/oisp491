function test1() {
    const req = indexedDB.open('example')
    // console.log(req)
    req.onsuccess = function(event) {
        // console.log(event.target === req)
        console.log(req.result)
    }
    req.onerror = function(err) {
        console.log(err)
    }
}

function test1() {
    const req = indexedDB.open('Peter')
    req.onupgradeneeded = function() {
        console.log('upgradeneeded')
    }
}

async function test1() {
    console.log(await indexedDB.databases())
}


async function test1() {
    const req = indexedDB.deleteDatabase('Artemik')
    req.onsuccess = function(event) {
        console.log('success')
    }
    req.onerror = function(err) {
        console.log(err)
    }
}

async function test1() {
    const arr = await indexedDB.databases()
    for (const obj of arr) {
        indexedDB.deleteDatabase(obj.name)
    }
}

async function test1() {
    const req = indexedDB.open('example')
    req.onupgradeneeded = function() {
        const db = req.result
        const result = db.createObjectStore('fruits', {
            keyPath: 'name',
        })
    }
    req.onsuccess = function() {
        const db = req.result
        const tx = db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        store.add({name: 'pear'})
        tx.oncomplete = function() {
            console.log('done')
        }
        tx.onerror = function() {
            console.log('error')
        }
    }
    req.onerror = function(err) {
        console.log(err)
    }
}
    async function test1() {
    const req = indexedDB.open('example')
    req.onupgradeneeded = function() {
        const db = req.result
        const result = db.createObjectStore('fruits', {
            keyPath: 'name',
        })
    }
    req.onsuccess = function() {
        const db = req.result
        const tx = db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const storeReq = store.getAll()
        storeReq.onsuccess = function() {
            console.log(storeReq.result)
        }
        tx.onerror = function() {
            console.log('error')
        }
    }
    req.onerror = function(err) {
        console.log(err)
    }
}

function test() {
    const writeFruit = document.querySelector('.writeFruit')
    const addButton = document.querySelector('.addFruit')
    addButton.addEventListener('click', onclick)
    const inputedValue = {
        name: writeFruit.value
    }


    function onclick() {
        console.log(123)
        const req = indexedDB.open('example')
        req.onupgradeneeded = function() {
            const db = req.result
            const result = db.createObjectStore('fruits', {
                keyPath: 'name',
            })
        }   
    req.onsuccess = function() {
        const db = req.result
        const tx = db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        store.add({name: writeFruit.value})
        const storeReq = store.getAll()
        storeReq.onsuccess = function() {
            console.log(storeReq.result)
            const dbObjects = document.createElement('div')
            dbObjects.append(storeReq.result)
        }
        tx.onerror = function() {
            console.log('error')
        }
    }
    req.onerror = function(err) {
        console.log(err)
    }
    }
}

test()

