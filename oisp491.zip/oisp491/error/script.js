function test1() {
    console.log('start')
    throw new Error('Some error')
    console.log('end')
}

function test() {
    try {
        console.log('start')
        throw new Error('Some error')
        console.log('end')
    } catch(err) {
        console.log('error has been caught')
    }
}

test()
