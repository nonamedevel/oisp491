/*
    Inspired by VS Code
    src\vs\platform\quickinput\browser\quickInputService.ts (parent)
    src\vs\workbench\services\quickinput\browser\quickInputService.ts (child)
*/

import { Person as BasePerson } from './lib.js'

class Person extends BasePerson {
    constructor(name, age) {
        super(name, age)
    }
    printInfo() {
        console.log('child', this.name, this.age)
    }
}

const person = new Person('John', 40)
person.printInfo()
