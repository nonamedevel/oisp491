class Person {
    constructor(name) {
        this.name = name
    }
    printInfo() {
        console.log(this.name)
    }
}

const person1 = new Person('Jack')
person1.printInfo()
const person2 = new Person('Jane')
person2.printInfo()
const person3 = new Person('Vasya')
person3.printInfo()