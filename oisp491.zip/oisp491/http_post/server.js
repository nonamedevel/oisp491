const http = require('http')
const fs = require('fs')

const users = [
    {
        login: '111',
        password: '222',
    }
]

const server = http.createServer(function(req, res) {
    console.log(req.url)
    if (req.url === '/') {
        fs.readFile('index.html', function(err, data) {
            res.end(data)
        })
    } else if (req.url === '/login') {
        let data = ''
        req.on('data', function(chunk) {
            data += chunk
        })
        req.on('end', function() {
            console.log(data)
            console.log(typeof data)
            const user = JSON.parse(data)
            console.log(user)
            console.log(typeof user)
            console.log(user.login)
            console.log(user.password)
            if (user.login === users[0].login && user.password === users[0].password) {
                res.end('success')
            } else {
                res.end('failure')
            }
        })        
    } else {
        res.end()
    }
})

server.listen(8000)