class ChangeNameWidget {
    constructor() {
        this.prefix = [
            0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
            0x01, 0x05, 0x01, // type
                0x60, 0x00, 0x01, 0x7f,
            0x03, 0x02, 0x01, 0x00, // function
        ]
        this.suffix = [
            0x0a, 0x06, 0x01, // code
                0x04, 0x00, 
                    0x41, 0x3f,
                0x0b,
        ]
        
        this.container = document.querySelector('.change_name_widget')
        this.input = this.container.querySelector('.name')
        this.button = this.container.querySelector('.change_name')
        this.button.addEventListener('click', this.onClick.bind(this))
    }
    createExportSection(funcName) {
        const sectionId = 7
        const itemCount = 1
        return [
            sectionId,
            funcName.length + 4,
            itemCount,
            funcName.length,
            ...this.toBytes(funcName),
            0, 0,
        ]
    }
    onClick() {
        const funcName = this.input.value
        this.input.value = ''
        const exportSection = this.createExportSection(funcName)
        const result = [
            ...this.prefix,
            ...exportSection,
            ...this.suffix
        ]
        WebAssembly.instantiate(new Uint8Array(result)).then(({instance}) => {
            const result = instance.exports[funcName]()
            console.log(result)
        })
    }
    toBytes(str) {
        const arr = []
        for(let i = 0; i < str.length; i++){
            let item = str[i].charCodeAt()
            arr.push(item)
        }
        return arr
    }
}

const changeNameWidget = new ChangeNameWidget()
