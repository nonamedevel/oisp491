const inputElem = document.querySelector('.funcNameInp')
const btnElem = document.querySelector('.funcNameBtn')
function test() {
    const wasmBytes1 = new Uint8Array([
        0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
        0x01, 0x05, 0x01, // type
            0x60, 0x00, 0x01, 0x7f,
        0x03, 0x02, 0x01, 0x00, // function
        0x07, 0x08, 0x01, // export
            0x04, 0x66, 0x75, 0x6e, 0x63, 0x00, 0x00,
        0x0a, 0x06, 0x01, // code
            0x04, 0x00, 
                0x41, 0x3f,
            0x0b,
    ])
    const wasmBytes = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 127, 3, 2, 1, 0, 7, 8, 1, 4, 97, 98, 99, 100, 0, 0, 10, 6, 1, 4, 0, 65, 63, 11])
    WebAssembly.instantiate(wasmBytes.buffer).then(({instance}) => {
        const result = instance.exports.abcd()
        console.log(result)
    })
}

function toBytes(str) {
    const arr = []
    for(let i = 0; i < str.length; i++){
        let item = str[i].charCodeAt()
        arr.push(item)
    }
    return arr
}

btnElem.addEventListener('click', () =>{
    const arr = [
        0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
        0x01, 0x05, 0x01, // type
            0x60, 0x00, 0x01, 0x7f,
        0x03, 0x02, 0x01, 0x00, // function
        0x07, 0x08, 0x01, // export
            0x04, 0x66, 0x75, 0x6e, 0x63, 0x00, 0x00,
        0x0a, 0x06, 0x01, // code
            0x04, 0x00, 
                0x41, 0x3f,
            0x0b,
    ]
    const prefix = arr.slice(0, 20)
    const suffix = arr.slice(27)
    const funcName = inputElem.value
    inputElem.value = ''
    const result = [...prefix, funcName.length + 4, 1 ,funcName.length, ...toBytes(funcName), ...suffix]
    const wasmBytes = new Uint8Array(result)
    WebAssembly.instantiate(wasmBytes.buffer).then(({instance}) => {
        const result = instance.exports[funcName]()
        console.log(result)
    })
})
