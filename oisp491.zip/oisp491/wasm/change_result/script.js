/*
    (1) Добавить возможность ввода с клавиатуры (в дополнение к кнопке)
    (2) Сделать рефакторинг (в ООП)
*/
class ChangeResultWidget{
    constructor(){
        const bytes = [
            0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
            0x01, 0x05, 0x01, // type
                0x60, 0x00, 0x01, 0x7f,
            0x03, 0x02, 0x01, 0x00, // function
            0x07, 0x08, 0x01, // export
                0x04, 0x66, 0x75, 0x6e, 0x63, 0x00, 0x00,
            0x0a, 0x06, 0x01, // code
                0x04, 0x00, 
                    0x41, 0x3f,
                0x0b,
        ]

        const changeResultWidget = document.querySelector('.change_result_widget')
        const resultInput = changeResultWidget.querySelector('.result')
        const changeResultButton = changeResultWidget.querySelector('.change_result')

        
        const changeResult = ()=>{
            bytes[35] = resultInput.value
            resultInput.value = ''
            const prefix = bytes.slice(0, 20)
            const suffix = bytes.slice(27)
            const funcName = 'func1'
            const result = [
                ...prefix,
                funcName.length + 4,
                1,
                funcName.length,
                ...this.toBytes(funcName),
                ...suffix
            ]
            const wasmBytes = new Uint8Array(result)
            WebAssembly.instantiate(wasmBytes.buffer).then(({instance}) => {
                const result = instance.exports[funcName]()
                console.log(result)
            })
        }
        changeResultButton.addEventListener('click', changeResult)
        
        
        resultInput.addEventListener('keydown', function(event) {
            if (event.code === 'Enter'){
                changeResult()
            }
        })

    }       
    toBytes(str) {
        const arr = []
        for(let i = 0; i < str.length; i++){
            let item = str[i].charCodeAt()
            arr.push(item)
        }
        return arr
    }
}

const changeResultWidget = new ChangeResultWidget()
