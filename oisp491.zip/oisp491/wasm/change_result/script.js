/*
    (1) Добавить возможность ввода с клавиатуры (в дополнение к кнопке)
    (2) Сделать рефакторинг (в ООП)
    -- Не следует использовать вложенные функции без реальной необходимости
    -- Функции должны выполнять строго определенные задачи
    (не должно быть функций которые решают сразу несколько задач)
*/
class ChangeResultWidget {
    constructor() {
        this.bytes = [
            0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
            0x01, 0x05, 0x01, // type
            0x60, 0x00, 0x01, 0x7f,
            0x03, 0x02, 0x01, 0x00, // function
            0x07, 0x08, 0x01, // export
            0x04, 0x66, 0x75, 0x6e, 0x63, 0x00, 0x00,
            0x0a, 0x06, 0x01, // code
            0x04, 0x00,
            0x41, 0x3f,
            0x0b,
        ]

        const changeResultWidget = document.querySelector('.change_result_widget')

        this.resultInput = changeResultWidget.querySelector('.result')
        this.resultInput.addEventListener('keydown', this.onKeyDown.bind(this))

        const changeResultButton = changeResultWidget.querySelector('.change_result')
        changeResultButton.addEventListener('click', this.changeResult.bind(this))
        
        this.errorElem = changeResultWidget.querySelector('.error')
        this.hideMessage = this.hideMessage.bind(this)
    }
    onKeyDown(event) {
        if (event.code === 'Enter') {
            this.changeResult()
        }
    }
    showMessage() {
        this.errorElem.classList.remove('hidden')
    }
    hideMessage() {
        this.errorElem.classList.add('hidden')
    }
    changeResult() {
        const number = Number(this.resultInput.value)
        if (number >= 64) {
            this.showMessage()
            setTimeout(this.hideMessage, 1000)
            return
        }
        this.bytes[35] = number
        this.resultInput.value = ''
        WebAssembly.instantiate(new Uint8Array(this.bytes)).then(({ instance }) => {
            const result = instance.exports.func()
            console.log(result)
        })
    }
}

const changeResultWidget = new ChangeResultWidget()
