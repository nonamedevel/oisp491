/*
    123456 --> [ 192, 196, 7 ]
    
    11110001001000000
    11000000 11000100 00000111
    1000000 1000100 111

    11110001001000000
*/
function encodeULEB128(value) {
    const bytes = []
    do {
        let byte = value & 0x7f
        value >>>= 7
        if (value != 0) {
            byte |= 0x80
        }
        bytes.push(byte)
    } while (value != 0)
    return bytes
}
// debugger
// const result = encodeULEB128(123456)
const result = encodeULEB128(0xFFFFFFFF)
console.log(result)

