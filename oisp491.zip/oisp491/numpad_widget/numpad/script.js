const container = document.querySelector('.container')
let number = ''
container.addEventListener('click', function(event) {
    if (event.target === container) {
        return
    }
    number += event.target.textContent
    console.log(Number(number))
})