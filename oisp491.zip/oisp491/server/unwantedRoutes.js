const http = require('http')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]
const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    res.end('hello')
})

server.listen(2500)
