const http = require('http')
const fs = require('fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]
const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        fs.readFile('C:/oisp491/server/static/index.html', 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url === '/about') {
        fs.readFile('C:/oisp491/server/static/about.html', 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url === '/contacts') {
        fs.readFile('C:/oisp491/server/static/contacts.html', 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else {
        res.writeHead(404, {
            'Content-Type': 'text/html'
        })
        res.end('<h4>404 not found</h4>')
    }
})

server.listen(2500)
