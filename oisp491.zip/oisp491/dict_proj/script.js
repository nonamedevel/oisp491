class App {
    constructor() {
        this.readData()
        if (!this.items) {
            this.items = []
        }

        const url = location.href.split('/').slice(-1)[0]
        if (url === "index.html") {
            this.container = document.querySelector('.add_word_widget')
            this.englishInput = this.container.querySelector('.english')
            this.russianInput = this.container.querySelector('.russian')
            this.addWordButton = this.container.querySelector('.add_word')
            this.addWordButton.disabled = true
            this.addWordButton.addEventListener('click', this.addWord.bind(this))
            this.englishInput.addEventListener('input', this.onInput.bind(this))
            this.russianInput.addEventListener('input', this.onInput.bind(this))
        } else if (url === "list.html") {
            this.list = document.querySelector('.list')
            this.content = document.querySelector('.content')
            for (const item of this.items) {
                const entry = document.createElement("div")
                entry.classList.add("row")
                const dash = document.createElement("div")
                const translation = document.createElement("div")
                const word1 = document.createElement("div")
                const delButton = document.createElement("button")
                delButton.textContent = "X"
                delButton.addEventListener("click", this.delEntry.bind(this))
                translation.textContent = item.translation
                word1.textContent = item.word
                dash.textContent = "-"

                this.content.append(entry)
                entry.append(word1)
                entry.append(dash)
                entry.append(translation)
                entry.append(delButton)
            }
        }
        
    }
    onInput() {
        if (this.englishInput.value.length > 0 && this.russianInput.value.length > 0) {
            this.addWordButton.disabled = false
        } else {
            this.addWordButton.disabled = true
        }
    }
    addWord() {
        const dictEntry = {
            word: this.russianInput.value,
            translation: this.englishInput.value,
        }
        this.russianInput.value = ''
        this.englishInput.value = ''
        this.items.push(dictEntry)
        this.writeData()
    }
    readData() {
        this.items = JSON.parse(localStorage.getItem('dict_proj'))
    }
    writeData() {
        localStorage.setItem('dict_proj', JSON.stringify(this.items))
    }
    delEntry() {
        console.log("Entry is deleted")
    }
}

console.dir(location.href.split('/').slice(-1)[0])

const app = new App()