class App {
    constructor() {
        this.container = document.querySelector('.container')
        this.englishInput = this.container.querySelector('.english')
        this.russianInput = this.container.querySelector('.russian')
        this.addWordButton = this.container.querySelector('.add_word')
        this.addWordButton.disabled = true
        this.addWordButton.addEventListener('click', this.addWord.bind(this))
        this.englishInput.addEventListener('input', this.onInput.bind(this))
        this.russianInput.addEventListener('input', this.onInput.bind(this))

        this.readData()
        if (!this.items) {
            this.items = []
        }
    }
    onInput() {
        if (this.englishInput.value.length > 0 && this.russianInput.value.length > 0) {
            this.addWordButton.disabled = false
        } else {
            this.addWordButton.disabled = true
        }
    }
    addWord() {
        const dictEntry = {
            word: this.russianInput.value,
            translation: this.englishInput.value,
        }
        this.items.push(dictEntry)
        this.writeData()
    }
    readData() {
        this.items = JSON.parse(localStorage.getItem('dict_proj'))
    }
    writeData() {
        localStorage.setItem('dict_proj', JSON.stringify(this.items))
    }
}

const app = new App()