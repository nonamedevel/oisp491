class AddWordWidget {
    constructor(app) {
        this.app = app
        this.setButton = document.querySelector('.goSettings')
        this.container = document.querySelector('.add_word_widget')
        this.englishInput = this.container.querySelector('.english')
        this.russianInput = this.container.querySelector('.russian')
        this.addWordButton = this.container.querySelector('.add_word')
        this.addWordButton.disabled = true
        this.addWordButton.addEventListener('click', this.addWord.bind(this))
        this.englishInput.addEventListener('input', this.onInput.bind(this))
        this.russianInput.addEventListener('input', this.onInput.bind(this))
        this.setButton.addEventListener('click', function() {
            window.location.href = "settings.html"
        })
        this.messageElem = this.container.querySelector(".message")
    }
    addWord() {
        this.messageElem.textContent = ''
        const dictEntry = {
            word: this.russianInput.value,
            translation: this.englishInput.value,
        }
        this.russianInput.value = ''
        this.englishInput.value = ''
        if (this.checkUp(dictEntry)) {
            this.messageElem.textContent = 'this element already exists'
            setTimeout(() => {
                this.messageElem.textContent = ''
            },2000)
            this.addWordButton.disabled = true
            return
        }
        this.addWordButton.disabled = true
        this.app.items.push(dictEntry)
        this.app.writeData()
    }
    onInput() {
        if (this.englishInput.value.trim().length > 0 && this.russianInput.value.trim().length > 0) {
            this.addWordButton.disabled = false
        } else {
            this.addWordButton.disabled = true
        }
    }
    checkUp(dictEntry) {
        for (const item of this.app.items) {
            if (item.word === dictEntry.word) {
                return true
            }
        }
    }
}

class ShowWordsWidget {
    constructor(app) {
        this.app = app
        this.list = document.querySelector('.list')
        this.content = document.querySelector('.content')
        this.title = document.querySelector('.title')
        this.clearDict = document.querySelector('.clearDict')
        this.clearDict.addEventListener('click', this.clearFunction.bind(this))
        if (this.app.items.length > 0) {
            this.title.textContent = "Dictionary:"
        } else {
            this.clearDict.disabled = true
            this.title.textContent = "The dictionary is empty"
        }
        for (let i = 0; i < this.app.items.length; i++) {
            const item = this.app.items[i]
            const entry = document.createElement("div")
            entry.classList.add("row")
            this.content.append(entry)

            const wordElem = document.createElement("div")
            wordElem.textContent = item.word
            entry.append(wordElem)

            const dashElem = document.createElement("div")
            dashElem.textContent = "-"
            entry.append(dashElem)

            const translationElem = document.createElement("div")
            translationElem.textContent = item.translation
            entry.append(translationElem)

            const delButton = document.createElement("button")
            delButton.textContent = "X"
            delButton.addEventListener("click", this.delEntry.bind(this))
            entry.append(delButton)
        }
    }
    clearFunction() {
        localStorage.removeItem('dict_proj')
        this.content.textContent = ''
        this.clearDict.disabled = true
        this.title.textContent = "The dictionary is empty"
    }
    delEntry(event) {
        console.log(event.target.parentElement)
        const index = this.findIndex(event.target.parentElement)
        event.target.parentElement.remove()

        const items = []
        for (let i = 0; i < this.app.items.length; i++) {
            if (i !== index) {
                items.push(this.app.items[i])
            }
        }
        this.app.items = items
        this.app.writeData()
        if (this.app.items.length === 0) {
            this.clearDict.disabled = true
            this.title.textContent = "The dictionary is empty"
        }
    }
    findIndex(elem) {
        for (let i = 0; i < this.content.childElementCount; i++) {
            if (elem == this.content.children[i]) {
                return i
            }
        }
    }
}
class Settings {
    constructor() {
        this.mainButton = document.querySelector('.toMain')
        this.dictButton = document.querySelector('.toDict')
        this.mainButton.addEventListener('click', function() {
            window.location.href = "index.html"
        })
        this.dictButton.addEventListener('click', function() {
            window.location.href = "list.html"
        })
    }
}
class App {
    constructor() {
        this.readData()
        if (!this.items) {
            this.items = []
        }

        const url = location.href.split('/').slice(-1)[0]
        if (url === "index.html") {
            this.addWordWidget = new AddWordWidget(this)
        } else if (url === "list.html") {
            this.showWordsWidget = new ShowWordsWidget(this)
        } else if (url === "settings.html") {
            this.settings = new Settings()
        } 
    }
    readData() {
        const str = localStorage.getItem('dict_proj')
        if (str) {
            this.items = JSON.parse(str)
        }
    }
    writeData() {
        localStorage.setItem('dict_proj', JSON.stringify(this.items))
    }
}

console.dir(location.href.split('/').slice(-1)[0])

const app = new App()