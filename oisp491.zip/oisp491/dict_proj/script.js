class App {
    constructor() {
        this.container = document.querySelector('.container')
        this.englishInput = this.container.querySelector('.english')
        this.russianInput = this.container.querySelector('.russian')
        this.addWordButton = this.container.querySelector('.add_word')
        this.addWordButton.disabled = true
        this.addWordButton.addEventListener('click', this.addWord.bind(this))
        console.log(this)
        this.englishInput.addEventListener('input', () => {
            console.log(this)
            // console.log(this.englishInput.value.length)
        })
        this.russianInput.addEventListener('input', () => {
            console.log(this)
            // console.log(this.russianInput.value.length)
        })
    }
    addWord() {
        const dictEntry = {
            word: this.russianInput.value,
            translation: this.englishInput.value,
        }
        console.log(dictEntry)
    }
}

const app = new App()