class App {
    constructor() {
        this.container = document.querySelector('.container')
        this.englishInput = this.container.querySelector('.english')
        this.russianInput = this.container.querySelector('.russian')
        this.addWordButton = this.container.querySelector('.add_word')
        this.addWordButton.addEventListener('click', this.addWord.bind(this))
    }
    addWord() {
        const dictEntry = {
            word: this.russianInput.value,
            translation: this.englishInput.value,
        }
        console.log(dictEntry)
    }
}

const app = new App()