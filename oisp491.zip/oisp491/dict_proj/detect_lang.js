function test() {
    // const word = 'привет'
    const word = 'hello'
    for (const char of word) {
        // console.log(char)
        console.log(char.charCodeAt())
    }
}

test()