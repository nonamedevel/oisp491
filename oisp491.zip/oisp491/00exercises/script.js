function test1() {
    // const color = 'black'
    let color = 'black'
    color = 'white'
    console.log(color)
}

function test1() {
    for (var i = 0; i < 5; i++) {
        console.log(i)
    }
    console.log(i)
}

function test1() {
    {
        const example1 = 1
        let example2 = 2
        var example3 = 3
    }
    // console.log(example1)
    // console.log(example2)
    console.log(example3)
}

function test() {
    function print(name, age) {
        console.log(name, age)
    }
    print("ivan", 16)
}

function test1(){
    let str1 = 'Привет'
    let str2 = "Привет"
    let str3 = `Привет`
    console.log(str1, str2, str3)
}

function test1(){
    let str = 'Привет мир'
    console.log(str.length)
}
function test1(){
    let str = 'Привет мир'
    // console.log(str.toUpperCase())
    console.log(str.toLowerCase())
}
function test() {
    const firstList = ['weg', 'dw', 'www']
    console.log(firstList.length)
    const secondList = [1,2,3,4,5]
    console.log(secondList[4])
    // многомерный массив
    const thirdList = [[1,2,3,4,5], [87,3,6], [43,9,123,4]]
    console.log(thirdList[1][0])
}
function test1(){
    for (let i = 4; i > -1; i--) {
        console.log("Счетчик:" , i);
    }
}
function test(){
    let i = 4;
    while (i > -1) {
        console.log(i)
        i--
    }
}

test()
