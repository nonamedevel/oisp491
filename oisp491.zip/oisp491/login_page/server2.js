const http = require('http')
const fs = require('fs')

const skipUrls = [
    '/favicon.ico',
    '/.well-known/appspecific/com.chrome.devtools.json',
]
const server = http.createServer(function(req, res) {
    if (!skipUrls.includes(req.url)) {
        console.log(req.url)
    }

    if (req.url === '/') {     
        fs.readFile('index.html', function(err, data) {
            res.end(data)
        })
    } else if (req.url === '/login') {
        fs.readFile('index.html', function(err, data) {
            res.end(data)
        })
    } else {
        res.end()
    }
})

server.listen(3001)
