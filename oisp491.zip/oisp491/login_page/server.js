const http = require('http')
const fs = require('fs')

const skipUrls = [
    '/favicon.ico',
    '/.well-known/appspecific/com.chrome.devtools.json',
]
function checkUserAgent(headers) {
    for (const header of Object.keys(headers)) {
        if (header === 'user-agent') {
            console.log(headers[header])
            break
        }
    }
}
const server = http.createServer(function(req, res) {
    if (!skipUrls.includes(req.url)) {
        console.log(req.url)        
        checkUserAgent(req.headers)
    }

    if (req.url === '/') {     
        fs.readFile('index.html', function(err, data) {
            res.writeHead(200, {
                'cookie': 555
            })
            res.end(data)
        })
    } else if (req.url === '/login') {
        fs.readFile('index.html', function(err, data) {
            res.end(data)
        })
    } else {
        res.end()
    }
})

server.listen(3000)
