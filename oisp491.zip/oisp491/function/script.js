// console.log('Name: John, Age: 50, City: London')
// console.log('Name: Masha, Age: 20, City: Sochi')
// console.log('Name: Vasya, Age: 30, City: Moscow')

// const user1 = 'Name: John, Age: 50, City: London'
// console.log(user1)
// const user2 = 'Name: Masha, Age: 20, City: Sochi'
// console.log(user2)
// const user3 = 'Name: Vasya, Age: 30, City: Moscow'
// console.log(user3)

// const users = [
//     'Name: John, Age: 50, City: London',
//     'Name: Masha, Age: 20, City: Sochi',
//     'Name: Vasya, Age: 30, City: Moscow',
// ]
// console.log(users[0])
// console.log(users[1])
// console.log(users[2])

function printUser(user) {
    console.log(`Name: ${user.name}, Age: ${user.age}, City: ${user.city}`)
}
const users = [
    {
        name: 'John',
        age: 50,
        city: 'London',
    },
    {
        name: 'Masha',
        age: 20,
        city: 'Sochi',
    },
    {
        name: 'Vasya',
        age: 30,
        city: 'Moscow',
    },
]
printUser(users[0])
printUser(users[1])
printUser(users[2])
