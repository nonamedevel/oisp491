/*
    Вызов функции
    Сначала мы опеределяем функцию, потом мы ее вызываем
*/
function test() { // function definition - определение функции
    console.log('example')
}

test() // function call - вызов функции
