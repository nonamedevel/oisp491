/*
    name, age, premium - это параметры
*/
function printInfo(name, age, premium) {
    console.log(name, age, premium)
}

/*
    'Vasya', 20, false - это аргументы
    'Masha', 30, true - это тоже аргументы
*/
printInfo('Vasya', 20, false)
printInfo('Masha', 30, true)