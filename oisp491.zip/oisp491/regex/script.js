/*
    Select all function calls in a file (simplified)
    [\.\w]+\([^=]*\)
*/

/*
    You have a string "hello world!".
    How do you check if it consists of only latin lower case letters and space characters? Avoid regular expressions.
*/

function test() {
    function isLowerCase(charCode) {
        return charCode >= 97 && charCode <= 122
    }
    function checkString(str) {
        for (let i = 0; i < str.length; i++) {
            const charCode = str.charCodeAt(i)
            if (!(isLowerCase(charCode) || charCode === 32)) {
                return false
            }
        }
        return true
    }
    console.log(checkString('hello world!'))
    console.log(checkString('hello world'))
}

test()