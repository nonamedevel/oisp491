/*
    Select all function calls in a file (simplified)
    [\.\w]+\([^=]*\)
*/
