/*

src\vs\base\browser\ui\tree\tree.ts

*/

// src\vs\base\browser\ui\tree\indexTreeModel.ts
class IndexTreeModel { // 92
    constructor() {
		this.root = {
			parent: undefined,
			element: rootElement,
			children: [],
			depth: 0,
			visibleChildrenCount: 0,
			visibleChildIndex: -1,
			collapsible: false,
			collapsed: false,
			renderNodeCount: 0,
			visibility: TreeVisibility.Visible,
			visible: true,
			filterData: undefined
		}
    }
    createTreeNode() {
		const node = {
			parent,
			element: treeElement.element,
			children: [],
			depth: parent.depth + 1,
			visibleChildrenCount: 0,
			visibleChildIndex: -1,
			collapsible: typeof treeElement.collapsible === 'boolean' ? treeElement.collapsible : (typeof treeElement.collapsed !== 'undefined'),
			collapsed: typeof treeElement.collapsed === 'undefined' ? this.collapseByDefault : treeElement.collapsed,
			renderNodeCount: 1,
			visibility: TreeVisibility.Visible,
			visible: true,
			filterData: undefined
		};
    }
}



// src\vs\workbench\contrib\preferences\browser\tocTree.ts
class TOCTreeModel { // 29

}
function createTOCIterator() { // 158

}
class TOCTree {
    
}


// src\vs\workbench\contrib\preferences\browser\settingsEditor2.ts
class SettingsEditor2 {
    refreshTOCTree() {
		if (this.isVisible()) {
			this.tocTreeModel.update();
			this.tocTree.setChildren(
                null, 
                createTOCIterator(this.tocTreeModel, this.tocTree)
            );
		}
    }
}
