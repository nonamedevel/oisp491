
// src\vs\base\browser\ui\dialog\dialog.ts
class Dialog {
    constructor() {
        const monacoWorkbench = document.createElement('div')
        monacoWorkbench.classList.add('monaco-workbench')
        document.body.append(monacoWorkbench)

        const monacoDialogModalBlock = document.createElement('div')
        monacoDialogModalBlock.classList.add('monaco-dialog-modal-block')
        monacoWorkbench.append(monacoDialogModalBlock)

        const dialogShadow = document.createElement('div')
        dialogShadow.classList.add('dialog-shadow')
        monacoDialogModalBlock.append(dialogShadow)

        const monacoDialogBox = document.createElement('div')
        monacoDialogBox.classList.add('monaco-dialog-box')
        dialogShadow.append(monacoDialogBox)

        const dialogMessageRow = document.createElement('div')
        dialogMessageRow.classList.add('dialog-message-row')
        monacoDialogBox.append(dialogMessageRow)

        const dialogMessageContainer = document.createElement('div')
        dialogMessageContainer.classList.add('dialog-message-container')
        dialogMessageRow.append(dialogMessageContainer)

        const dialogMessage = document.createElement('div')
        dialogMessage.classList.add('dialog-message')
        dialogMessageContainer.append(dialogMessage)

        /*
            monaco-dialog-message-text (id)
            dialog-message-text (class)
            They are not used anywhere.
        */
        const monacoDialogMessageText = document.createElement('div')
        monacoDialogMessageText.textContent = 'Visual Studio Code'
        dialogMessage.append(monacoDialogMessageText)
    }
}


// src\vs\workbench\browser\parts\dialogs\dialogHandler.ts
class BrowserDialogHandler {
    about() {
        this.doShow()
    }
    doShow() { // 91
        const dialog = new Dialog()
    }
}

// src\vs\base\common\lazy.ts
class Lazy {
    constructor(executor) {
        this.executor = executor
    }
    get value() {
        this._value = this.executor()
        return this._value
    }
}

// src\vs\workbench\browser\parts\dialogs\dialog.web.contribution.ts
class DialogHandlerContribution {
    constructor() {
        // this.impl = {
        //     value: new BrowserDialogHandler()
        // }
        this.impl = new Lazy(() => new BrowserDialogHandler())
        this.processDialogs()
    }
    processDialogs() {
        this.impl.value.about()
    }
}

const dialogHandlerContribution = new DialogHandlerContribution()

