/*
    C:\Users\<username>\AppData\Roaming\Code\User\settings.json

    "editor.cursorBlinking": "solid"

*/

/*
    Exercise: Extract user settings from IndexedDB and print them

*/

const req = indexedDB.open('vscode-web-db')

req.onsuccess = function() {
    const db = req.result
    const tx = db.transaction('vscode-userdata-store', 'readwrite')
    const store = tx.objectStore('fruits')
    store.add({name: writeFruit.value})
}
