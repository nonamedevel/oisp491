
this.disposables.add(
    onClick(
        element, 
        () => this.openerService.open(
            extension.location, 
            { openExternal: true }
        )
    )
);

function func1() {
    this.openerService.open(extension.location, { 
        openExternal: true 
    })
}
const disposable = onClick(element, func1)
this.disposables.add(disposable);
