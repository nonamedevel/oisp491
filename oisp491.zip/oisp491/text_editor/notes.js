/*


ExtensionEditor.render
    ExtensionEditor.renderNavbar
        ExtensionEditor.onNavbarChange
            ExtensionEditor.open
                ExtensionEditor.openDetails
                    ExtensionEditor.renderAdditionalDetails
                        AdditionalDetailsWidget.constructor                         src\vs\workbench\contrib\extensions\browser\extensionEditor.ts
                            AdditionalDetailsWidget.render                          src\vs\workbench\contrib\extensions\browser\extensionEditor.ts
                                AdditionalDetailsWidget.renderMarketplaceInfo       src\vs\workbench\contrib\extensions\browser\extensionEditor.ts
                                    "Last Released"



obsucate
deobfuscate ~ reverse engineering
*/

this.disposables.add(
    onClick(
        element, 
        () => this.openerService.open(
            extension.location, 
            { openExternal: true }
        )
    )
);

function func1() {
    this.openerService.open(extension.location, { 
        openExternal: true 
    })
}
const disposable = onClick(element, func1)
this.disposables.add(disposable);
