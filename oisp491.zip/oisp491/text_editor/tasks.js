/*

(1) Выяснить как реализован функционал "скрыть/показать Primary Side Bar" (при нажатии Ctrl + B) - ГЮА
(2) Когда мы открываем новый файл, он загружается в определенную структуру данных. Найти эту структуру данных и выяснить как она работает - БА
(3) Мы можем создавать или изменять "горячие клавиши" с помощью диалога Keyboard Shortcuts. Это таблица которая открывается в новой вкладке. Выяснить как реализован этот функционал - БАК
(4) Как реализовано переключение между вкладками - КИД
(5) Как реализована история Undo/Redo - БВС
(6) Как реализовано позиционирование курсора внутри файла (Line, Column) - УГМ
(7) Как реализована кнопка Restore Defaults в диалоге Customize Layout - ТЮЮ

(8) Изучить как работают disposables (DisposableStore, IDisbosable и т.д.)
(9) Выяснить как реализованы картинки на кнопках в UI (Codicon и т.п.). Например, "два листочка бумаги" - это Explorer, "шестеренка" - это Manage, "увеличительное стекло" - это поиск

*/

CreateToggleLayoutItem(
    ToggleSidebarVisibilityAction.ID, 
    SideBarVisibleContext, 
    localize('sideBar', "Primary Side Bar"), 
    { 
        whenA: ContextKeyExpr.equals('config.workbench.sideBar.location', 'left'), 
        iconA: panelLeftIcon, 
        iconB: panelRightIcon 
    }
)


