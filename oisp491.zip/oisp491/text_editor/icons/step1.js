/*

Keyboard Shortcuts favicon
src\vs\editor\standalone\browser\iPadShowKeyboard\keyboard-light.svg



ThemeIcon.asClassName               src\vs\workbench\browser\actions\layoutActions.ts

src\vs\base\common\codiconsLibrary.ts

register            src\vs\base\common\codiconsUtil.ts









*/