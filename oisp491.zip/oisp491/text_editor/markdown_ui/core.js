const vscode = {
    commands: {
        registerCommand() {
            
        }
    }
}

