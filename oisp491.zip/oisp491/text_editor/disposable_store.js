
class DisposableStore {
	static DISABLE_DISPOSED_WARNING = false;
	_toDispose = new Set();
	_isDisposed = false;

	constructor() {
		trackDisposable(this);
	}
	dispose() {
		if (this._isDisposed) {
			return;
		}
		markAsDisposed(this);
		this._isDisposed = true;
		this.clear();
	}
	get isDisposed() {
		return this._isDisposed;
	}
	clear() {
		if (this._toDispose.size === 0) {
			return;
		}

		try {
			dispose(this._toDispose);
		} finally {
			this._toDispose.clear();
		}
	}

	add(o) {
		if (!o || o === Disposable.None) {
			return o;
		}
		if ((o) === this) {
			throw new Error('Cannot register a disposable on itself!');
		}

		setParentOfDisposable(o, this);
		if (this._isDisposed) {
			if (!DisposableStore.DISABLE_DISPOSED_WARNING) {
				console.warn(new Error('Trying to add a disposable to a DisposableStore that has already been disposed of. The added object will be leaked!').stack);
			}
		} else {
			this._toDispose.add(o);
		}

		return o;
	}
	delete(o) {
		if (!o) {
			return;
		}
		if ((o) === this) {
			throw new Error('Cannot dispose a disposable on itself!');
		}
		this._toDispose.delete(o);
		o.dispose();
	}
	deleteAndLeak(o) {
		if (!o) {
			return;
		}
		if (this._toDispose.has(o)) {
			this._toDispose.delete(o);
			setParentOfDisposable(o, null);
		}
	}
	assertNotDisposed() {
		if (this._isDisposed) {
			onUnexpectedError(new BugIndicatingError('Object disposed'));
		}
	}
}

class BugIndicatingError {}
function setParentOfDisposable() {}
function trackDisposable(){}
function markAsDisposed(){}
class Disposable {}

const disposableStore = new DisposableStore ()
disposableStore.assertNotDisposed()
disposableStore.dispose()
DisposableStore.DISABLE_DISPOSED_WARNING = true
disposableStore.add({})