// debugger

// src\vs\platform\actions\common\actions.ts
let customizeLayoutAction

function registerAction2(ctor) {
    customizeLayoutAction = new ctor()
}

// src\vs\workbench\browser\actions\layoutActions.ts
registerAction2(class CustomizeLayoutAction {
    run(accessor) {
        const quickInputService = accessor.get()
        const quickPick = quickInputService.createQuickPick()
        
        const resetButton = {
            tooltip: 'Restore Defaults'
        }
        
        quickPick.buttons = [
            resetButton,
        ]
    }
})

// src\vs\platform\quickinput\browser\quickInput.ts
class QuickInput {
    constructor(ui) {
        this.ui = ui
    }
}

class QuickPick extends QuickInput {
    constructor(ui) {
        super(ui)
    }
    set buttons(arr) {
        this.tooltipElem.textContent = arr[0].tooltip
    }
}

// src\vs\platform\quickinput\browser\quickInputController.ts
class QuickInputController {
    createQuickPick() {
        const ui = this.getUI()
        return new QuickPick(ui) 
    }
    getUI() {
        const restoreDefaultsButton = document.createElement('button')
        document.body.append(restoreDefaultsButton)
        restoreDefaultsButton.textContent = 'Arrow'
        restoreDefaultsButton.addEventListener('click', function() {
            console.log('click')
        })
        restoreDefaultsButton.addEventListener('mouseenter', () => {
            this.tooltipElem.style.display = ''
        })
        restoreDefaultsButton.addEventListener('mouseleave', () => {
            this.tooltipElem.style.display = 'none'
        })

        this.tooltipElem = document.createElement('div')
        this.tooltipElem.style.display = 'none'
        this.tooltipElem.classList.add('tooltip')
        document.body.append(this.tooltipElem)
    }
}

// src\vs\platform\quickinput\browser\quickInputService.ts
class QuickInputService {
    constructor() {
        this._controller = null
    }
	get controller() {
		if (!this._controller) {
			this._controller = new QuickInputController()
		}

		return this._controller
	}
    createQuickPick() {
        return this.controller.createQuickPick()
    }
}


// src\vs\workbench\services\quickinput\browser\quickInputService.ts

customizeLayoutAction.run({
    get() {
        const quickInputService = new QuickInputService()
        return quickInputService
    }
})
