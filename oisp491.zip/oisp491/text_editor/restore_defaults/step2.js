
function run(accessor) {
    const quickInputService = accessor.get()
    const quickPick = quickInputService.createQuickPick()
    
    const resetButton = {
        tooltip: 'Restore Defaults!!'
    }
    
    quickPick.buttons = [
        resetButton,
    ]
}

class QuickPick {
    constructor() {
        const restoreDefaultsButton = document.createElement('button')
        document.body.append(restoreDefaultsButton)
        restoreDefaultsButton.textContent = 'Arrow'
        restoreDefaultsButton.addEventListener('click', function() {
            console.log('Restore Defaults')
        })
        restoreDefaultsButton.addEventListener('mouseenter', () => {
            this.tooltipElem.style.display = ''
        })
        restoreDefaultsButton.addEventListener('mouseleave', () => {
            this.tooltipElem.style.display = 'none'
        })

        this.tooltipElem = document.createElement('div')
        this.tooltipElem.style.display = 'none'
        this.tooltipElem.classList.add('tooltip')
        document.body.append(this.tooltipElem)
    }
    set buttons(arr) {
        this.tooltipElem.textContent = arr[0].tooltip
    }
}

run({
    get() {
        return {
            createQuickPick() {
                return new QuickPick() 
            }
        }
    }
})
