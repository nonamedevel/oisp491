const restoreDefaultsButton = document.createElement('button')
document.body.append(restoreDefaultsButton)
restoreDefaultsButton.textContent = 'Arrow'
restoreDefaultsButton.addEventListener('click', function() {
    console.log('Restore Defaults')
})
restoreDefaultsButton.addEventListener('mouseenter', function() {
    tooltipElem.style.display = ''
})
restoreDefaultsButton.addEventListener('mouseleave', function() {
    tooltipElem.style.display = 'none'
})

const tooltipElem = document.createElement('div')
tooltipElem.textContent = 'Restore Defaults'
tooltipElem.style.display = 'none'
tooltipElem.classList.add('tooltip')
document.body.append(tooltipElem)
