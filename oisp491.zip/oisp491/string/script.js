function test1() {
    const singleQuotes = 'Single quotes'
    const doubleQuotes = "Double quotes"
    const backticks = `Backticks`
    console.log(singleQuotes)
    console.log(doubleQuotes)
    console.log(backticks)
}

function test1() {
    const singleQuotes = "'Single quotes' inside double quotes."
    const doubleQuotes = '"Double quotes" inside single quotes.'
    console.log(singleQuotes)
    console.log(doubleQuotes)
}

function test1() {
    const imageIndex = 3
    const imageNames = [
        'image_1.png',
        'image_2.png',
        'image_3.png',
        'image_4.png',
        'image_5.png',
    ]
    const title = `Image ${imageIndex} out of ${imageNames.length}`
    console.log(title)
}

function test1() {
    const multilineString = `line #1
line #2
line #3`
    console.log(multilineString)
}

function test1() {
    const imageName = 'image_3.png'
    // console.log(imageName[0])
    // console.log(imageName[1])
    // console.log(imageName[2])
    // console.log(imageName[3])
    // console.log(imageName[4])
    // console.log(imageName[5])
    // console.log(imageName[6])
    for (let i = 0; i < imageName.length; i++) {
        console.log(imageName[i])
    }
}

function test1() {
    const imageName = 'image_3.png'
    console.log(imageName.slice(-3))
    console.log(imageName.slice(8))
    console.log(imageName.slice(6, 7))
}

function test1() {
    const imageNames = [
        'image_1.png',
        'image_23.png',
        'image_456.png',
    ]
    // console.log(imageNames[0].slice(6, 7))
    // console.log(imageNames[1].slice(6, 8))
    // console.log(imageNames[2].slice(6, 9))

    for (let i = 0; i < imageNames.length; i++) {
        const start = imageNames[i].indexOf('_') + 1
        const end = imageNames[i].indexOf('.')
        console.log(imageNames[i].slice(start, end))
    }
}

function test1() {
    const imageName = 'image_123.png'
    console.log(imageName.indexOf('_'))
    console.log(imageName.indexOf('.'))
    console.log(imageName.slice(6, 9))
    const start = imageName.indexOf('_') + 1
    const end = imageName.indexOf('.')
    console.log(imageName.slice(start, end))
}

function test1() {
    const imageName = 'image_123.png'
    console.log(imageName.indexOf('i'))
    console.log(imageName.indexOf('_'))
    console.log(imageName.indexOf('w'))
}

function test1() {
    const imageName = ['image_', 123, '.png']
    // console.log(imageName)
    console.log(imageName.join(''))
}

function test1() {
    const phoneNumber = [123, 45, 67]
    console.log(phoneNumber)
    console.log(phoneNumber.join('-'))
}

function test() {
    const phoneNumber = '123-45-67'
    console.log(phoneNumber)
    const arr = phoneNumber.split('-')
    console.log(arr)
    for (let i = 0; i < arr.length; i++) {
        arr[i] = Number(arr[i])
    }
    console.log(arr)
}

test()
