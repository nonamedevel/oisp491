function test1() {
    const singleQuotes = 'Single quotes'
    const doubleQuotes = "Double quotes"
    const backticks = `Backticks`
    console.log(singleQuotes)
    console.log(doubleQuotes)
    console.log(backticks)
}

function test1() {
    const singleQuotes = "'Single quotes' inside double quotes."
    const doubleQuotes = '"Double quotes" inside single quotes.'
    console.log(singleQuotes)
    console.log(doubleQuotes)
}

function test1() {
    const imageIndex = 3
    const imageNames = [1,2,3,4,5]
    const title = `Image ${imageIndex} out of ${imageNames.length}`
    console.log(title)
}

function test() {
    const multilineString = `line #1
line #2
line #3`
    console.log(multilineString)
}

test()
