
function randomInt(upperBound) {
    return Math.floor(Math.random() * upperBound)
}

module.exports = {
    randomInt
}
