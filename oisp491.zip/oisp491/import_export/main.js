const {randomInt} = require('./lib.js')

console.log(randomInt(10))
console.log(randomInt(100))
console.log(randomInt(1000))
