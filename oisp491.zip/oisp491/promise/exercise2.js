/*
    Дано: массив [
        {num: 5, delay: 2},
        {num: 10, delay: 1},
        {num: 15, delay: 3},
    ]
    Необходимо напечатать сумму чисел в данном массиве.
    Количество элементов в массиве может меняться.
*/

function main(arr){
    let promises = []
    for(let item of arr){
        promises.push(setPromise(item.num, item.delay)) 
    }
    let sum = 0
    let counter = 0
    for(let promise of promises){
        promise.then((num) => {
            counter++
            sum += num
            if(counter == promises.length){
                console.log(sum)
            }
        })
    }
}

function setPromise(num, delay){
    return new Promise((res, rej) =>{
        setTimeout(() =>{
            res(num)
        },delay * 1000)
    })
}
main([
    {num: 5, delay: 2},
    {num: 10, delay: 1},
    {num: 15, delay: 3},
])
