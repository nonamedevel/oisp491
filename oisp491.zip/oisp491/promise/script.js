function test1() {
    const promise = new Promise(function(res, rej) {
        res(400)
    })
    console.log(promise + 100)
    promise.then(function(num) {
        console.log(num + 100)
    })
}

function test1() {
    function asyncTask(delay) {
        return new Promise(function(res, rej) {
            setTimeout(function() {
                res(400)
            }, delay)
        })
    }
    const promise = asyncTask(2000)
    promise.then(function(num) {
        console.log(num + 100)
    })
}

function test() {
    function asyncTask(delay) {
        return new Promise(function(res, rej) {
            setTimeout(function() {
                res(400)
            }, delay)
        })
    }
    async function main() {
        const num = await asyncTask(0)
        // const num = await asyncTask(2000)
        console.log(num + 100)
    }
    main()
}

test()
