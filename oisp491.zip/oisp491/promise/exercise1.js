/*
    (1) Создать 2 числа:
    число 100 создается через 2 секунды
    число 200 создается через 3 секунды

    (2) Сложить эти числа и напечатать результат (300)
    */
function test() {
    function sum() {
        if (listNum.length === 2) {
            var result = 0
            for (const num of listNum) {
                result += num
            }
            console.log(result)
        }
    }
    var listNum = []
    setTimeout(function () {
        const firstNum = 100
        listNum.push(firstNum)
        sum()
    }, 2000)

    setTimeout(function () {
        const firstNum = 200
        listNum.push(firstNum)
        sum()
    }, 3000)
}

test()
