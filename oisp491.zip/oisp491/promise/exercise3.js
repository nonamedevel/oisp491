// найти минимальную стоимость чего-то
const prices = [
    new Promise((res) => setTimeout(() => res(700), 3500)),
    new Promise((res) => setTimeout(() => res(500), 1000)),
    new Promise((res) => setTimeout(() => res(5000), 1500)),
    new Promise((res) => setTimeout(() => res(9000), 300)),
    // new Promise((res) => setTimeout(() => res(3000), 2000)),
    new Promise(function(res) {
        setTimeout(function() {
            res(3000)
        }, 2000)
    })
]
const minimalPrice = []
async function main() {
    for (const price of prices) {
        minimalPrice.push(await price)
    }
    console.log(Math.min(...minimalPrice))
    // ... - извлекает элементы из массива
}

main()
