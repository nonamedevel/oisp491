function test1() {
    let sum = 0
    let i = 0
    for (; sum < 10; i++) {
        sum += Math.random()
    }
    console.log(i)
}
function test1() {
    let sum = 0
    for (let i = 0; i < 11; i++) {
        sum += 0.99999
    }
    console.log(sum)
}

function test() {
    const counters = {} 
    for (let i = 0; i < 1e6; i++) {
        const num = Math.floor(Math.random() * 10) + 1
        if (counters[num] === undefined) {
            counters[num] = 1
        } else {
            counters[num]++
        }
    }
    console.log(counters)
}

test()
// генерировать миллион рандомных чисел  и посчитать с нуля до десяти
// сколько чисел было сгенерировано