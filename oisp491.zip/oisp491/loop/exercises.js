/*
    Convert this:
    [1, 0, 1, 0, 1, 0, 1, 0]
    to this:
    '0b10101010'
*/
function test() {
    function strToArr(str) {
        arr = []
        for (let i = 2; i < str.length; i++) {
            // console.log(str[i])
            arr.push(Number(str[i]))
        }
        return arr
    }
    console.log(strToArr('0b10111010'))
    function arrToStr(arr) {
        let str = '0b'
        for (let digit of arr) {
            str += digit
        }
        return str 
    }
    // console.log(arrToStr([1, 1, 0, 0, 1, 0, 1, 0]))
}

test()
