function test1() {
    for (let i = 0; i < 5; i++) {
        console.log(i)
    }
}

function test1() {
    for (let i = 4; i >= 0; i--) {
        console.log(i)
    }
}

function test1() {
    console.log('start')
    for (let i = 0; i < 5000000000; i++) {}
    console.log('end')
}

function test1() {
    console.log('start')
    for (let i = 0; i < 5000000000; i++);
    console.log('end')
}

function test1() {
    console.log('start')
    for (let i = 0; i < 5; i++)
        console.log('end')
}

/*
    Used in obfuscated code,
    do not use in normal code!
*/
function test1() {
    for (let i = 0; console.log('hello'), i < 5; i++);
}

function test() {
    const str = 'ddd'
    for (let i = 0; i < str.length; i++) {
        // console.log(i)
        // console.log(str[i])
        console.log(str.charCodeAt(i))
    }
}

test()
