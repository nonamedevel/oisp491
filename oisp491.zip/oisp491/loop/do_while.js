function test1() {
    while(false) {
        console.log(123)
    }
    do {
        console.log(456)
    } while(false)
}

function test() {
    let i = 0
    while(i < 3) {
        console.log(123)
        i++
    }

    i = 0
    do {
        console.log(456)
        i++
    } while(i < 3)
}

debugger
test()
