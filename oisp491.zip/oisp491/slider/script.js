const sliderWidget = document.querySelector('.slider_widget')
const content = sliderWidget.querySelector('.content')
const controls = sliderWidget.querySelector('.controls')
const prevButton = controls.querySelector('.prev')
const nextButton = controls.querySelector('.next')
controls.addEventListener('click', function(event) {
    if (event.target.classList.contains('prev')) {
        imageIndex--
        showImage(imageIndex)
    } else if (event.target.classList.contains('next')) {
        imageIndex++
        showImage(imageIndex)
    }
})
document.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowLeft') {
        imageIndex--
        showImage(imageIndex)
    } else if (event.key === 'ArrowRight') {
        imageIndex++
        showImage(imageIndex)
    }
})

const imageNames = [
    'antonio-verdin-ZAa7XGbj09w-unsplash.jpg',
    'chris-lynch-DkCGxSPNowg-unsplash.jpg',
    'christian-agbede-PRAEF6vwMzw-unsplash.jpg',
    'francesco-ungaro-89uLQTLt8Dk-unsplash.jpg',
    'zhenyu-luo-sYhHjzOQfd0-unsplash.jpg',
]
let imageIndex = 0
function showImage(index) {
    if (index === -1) {
        imageIndex = 0
        return
    }
    if (index === imageNames.length) {
        imageIndex = imageNames.length - 1
        return
    }
    content.innerHTML = ''
    const imageElem = document.createElement('img')
    imageElem.height = 400
    imageElem.src = 'resources/' + imageNames[index]
    content.append(imageElem)

    const titleElem = document.createElement('div')
    titleElem.textContent = imageNames[index]
    content.append(titleElem)
    document.title = `Image ${imageIndex + 1} out of ${imageNames.length}`
    if (index === 0) {
        prevButton.disabled = true
    } else {
        prevButton.disabled = false
    }
    if (index === (imageNames.length - 1)) {
        nextButton.disabled = true
    } else {
        nextButton.disabled = false
    }
}
showImage(imageIndex)
