const sliderWidget = document.querySelector('.slider_widget')
const content = sliderWidget.querySelector('.content')
const controls = sliderWidget.querySelector('.controls')
controls.addEventListener('click', function(event) {
    if (event.target.classList.contains('prev')) {
        imageIndex--
        showImage(imageIndex)
    } else if (event.target.classList.contains('next')) {
        imageIndex++
        showImage(imageIndex)
    }
})
document.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowLeft') {
        imageIndex--
        showImage(imageIndex)
    } else if (event.key === 'ArrowRight') {
        imageIndex++
        showImage(imageIndex)
    }
})

const imageNames = [
    'antonio-verdin-ZAa7XGbj09w-unsplash.jpg',
    'chris-lynch-DkCGxSPNowg-unsplash.jpg',
    'christian-agbede-PRAEF6vwMzw-unsplash.jpg',
    'francesco-ungaro-89uLQTLt8Dk-unsplash.jpg',
    'zhenyu-luo-sYhHjzOQfd0-unsplash.jpg',
]
let imageIndex = 0
function showImage(index) {
    if (index === -1) {
        imageIndex = 0
        return
    }
    if (index === imageNames.length) {
        imageIndex = imageNames.length - 1
        return
    }
    content.innerHTML = ''
    const imageElem = document.createElement('img')
    imageElem.height = 400
    imageElem.src = 'resources/' + imageNames[index]
    content.append(imageElem)
}
showImage(imageIndex)
