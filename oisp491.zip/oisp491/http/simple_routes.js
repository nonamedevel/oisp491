const http = require('http')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]
const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        res.end('main page')
    } else if (req.url === '/about') {
        res.end('about page')
    } else if (req.url === '/contacts') {
        res.end('contacts page')
    } else {
        res.end('404 not found')
    }
})

server.listen(2500)
