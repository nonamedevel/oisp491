const http = require('http')
const fs = require('fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]
const folderPath = 'C:/oisp491/http/static/'
const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        fs.readFile(folderPath+"index.html", 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url === '/about') {
        fs.readFile(folderPath+"about.html", 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url === '/contacts') {
        fs.readFile(folderPath+"contacts.html", 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else {
        fs.readFile(folderPath+"404.html", 'utf8', function(err, data) {
            if (err) throw err
            res.writeHead(404, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    }
})

server.listen(2500)
