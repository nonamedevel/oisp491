const http = require('http')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]
const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        res.writeHead(200, {
            'Content-Type': 'text/html'
        })
        res.end('<h1>main page</h1>')
    } else if (req.url === '/about') {
        res.writeHead(200, {
            'Content-Type': 'text/html'
        })
        res.end('<h2>about page</h2>')
    } else if (req.url === '/contacts') {
        res.writeHead(200, {
            'Content-Type': 'text/html'
        })
        res.end('<h3>contacts page</h3>')
    } else {
        res.writeHead(404, {
            'Content-Type': 'text/html'
        })
        res.end('<h4>404 not found</h4>')
    }
})

server.listen(2500)
