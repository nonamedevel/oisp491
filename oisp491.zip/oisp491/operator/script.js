/*
    % - modulo
*/
function test1() {
    const remainder = 7 % 2
    console.log(remainder)
}

/*
    Increment
*/
function test1() {
    let num = 150
    // num += 1
    num++
    console.log(num)
    // num += 1
    num++
    console.log(num)
}

/*
    Decrement
*/
function test() {
    let num = 150
    // num -= 1
    num--
    console.log(num)
    // num -= 1
    num--
    console.log(num)
}

test()
