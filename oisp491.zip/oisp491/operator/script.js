/*
    % - modulo
*/
function test() {
    const remainder = 7 % 2
    console.log(remainder)
}

test()
