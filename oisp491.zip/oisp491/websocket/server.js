const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })
const connections = []

wss.on('connection', function (ws) {
    let countMessage = 0
    connections.push({ws})
    console.log("ws")
    ws.on('error', console.error)
    ws.on('message', function (data) {
        if(countMessage == 0){
            // let username =
        }
        data = data.toString()


        for (const connection of connections) {
            if (connection !== ws) {
                connection.ws.send(JSON.stringify({
                    text: data,
                    name: 'ivan'
                }))
            }
        }
    })
})
