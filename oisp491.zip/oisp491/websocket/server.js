const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })
const connections = new Map()

wss.on('connection', function (ws) {
    connections.set(ws, null)
    ws.on('error', console.error)
    ws.on('message', function (data) {
        const messageObject = JSON.parse(data)
        if (messageObject.type === "user_name") {
            connections.set(ws, messageObject.data)
        } else if (messageObject.type === "text_message") {
            for (const [key, val] of connections) {
                if (key !== ws) {
                    key.send(JSON.stringify({
                        type: "text_message",
                        data: messageObject.data,
                        name: val
                    }))
                }
            }
        }
    })
})
