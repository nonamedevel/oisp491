const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })
const connections = []
wss.on('connection', function (ws) {
    connections.push({ws})
    console.log("ws")
    ws.on('error', console.error)
    let messageCount = 0
    ws.on('message', function (data) {
        if(messageCount == 0){
            
        }
        messageCount++
        data = data.toString()


        for (const connection of connections) {
            if (connection !== ws) {
                connection.send(data)
            }
        }
    })
})
