const http = require('http')
const users = [
    {
        name: 'John',
        age: 50,
        city: 'London',
        premium: true,
    },
    {
        name: 'Masha',
        age: 20,
        city: 'Sochi',
        premium: true,
    },
    {
        name: 'Vasya',
        age: 30,
        city: 'Moscow',
        premium: false,
    },
]
const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]
const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        res.writeHead(200, {
            'Content-Type': 'text/html'
        })
        let data = `<div style="
            display: flex;
            flex-direction: column;
            gap: 20px;
        ">`
        for (const user of users) {
            let premiumStatus 
            if (user.premium) {
                premiumStatus = '<div style="color: red;">Premium User</div>'
            } else {
                premiumStatus = ''
            }
            data += `<div>
                <div>Name: ${user.name}</div>
                <div>Age: ${user.age}</div>
                <div>City: ${user.city}</div>
                ${premiumStatus}
            </div>`
        }
        data += '</div>'
        res.end(data)
    } else {
        res.writeHead(404, {
            'Content-Type': 'text/html'
        })
        res.end('<h4>404 not found</h4>')
    }
})

server.listen(2500)
