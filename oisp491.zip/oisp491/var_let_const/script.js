/*
    var - variable (переменная)
*/

/*
    Problem #1
    It's possible to accidentally redeclare a variable
*/
function test1() {
    var userName = 'Vasya'
    // let userName = 'Vasya'
    // const userName = 'Vasya'
    console.log(userName)

    var userName = 'Masha'
    // let userName = 'Masha'
    // const userName = 'Masha'
    console.log(userName)
}

/*
    Problem #2
    The scope is unnecessarily wide
*/
function test() {
    // for (var i = 0; i < 5; i++) {
    //     console.log(i)
    // }

    // for (let i = 0; i < 5; i++) {
    //     console.log(i)
    // }
    
    // let i = 0
    // for (; i < 5; i++) {
    //     console.log(i)
    // }
    
    let i
    for (i = 0; i < 5; i++) {
        console.log(i)
    }
    console.log(i)
}

test()