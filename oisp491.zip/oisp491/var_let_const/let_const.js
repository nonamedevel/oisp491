function test() {
    var userName = 'Vasya'
    // let userName = 'Vasya'
    // const userName = 'Vasya'
    console.log(userName)
    userName = 'Masha'
    console.log(userName)
}

test()
