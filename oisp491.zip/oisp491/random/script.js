function test1() {
    console.log(Math.random())
    console.log(Math.random())
    console.log(Math.random())
}

function test1() {
    console.log(Math.random() * 10)
    console.log(Math.random() * 10)
    console.log(Math.random() * 10)
}

function test() {
    console.log(Math.floor(Math.random() * 10))
    console.log(Math.floor(Math.random() * 10))
    console.log(Math.floor(Math.random() * 10))
}

test()
