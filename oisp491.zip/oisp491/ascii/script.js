function test() {
    const str = 'abc'
    // const str = 'абв'
    console.log(str[0])
    // console.log(str[0].charCodeAt())
    console.log(str.charCodeAt(0))
    console.log(str.charCodeAt(1))
    console.log(str.charCodeAt(2))
}

test()