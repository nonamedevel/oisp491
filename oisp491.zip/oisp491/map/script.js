function test1() {
    const map = new Map()
    map.set('map', 'карта')
    map.set('list', 'список')
    map.set('function', 'функция')
    map.set('promise', 'обещание')
    map.set('promise', 'промис')
    console.log(map)
}

function test() {
    const obj = {
        map: 'карта',
        list: 'список',
        function: 'функция',
        promise: 'обещание',
        promise: 'промис',
    }
    console.log(obj)
}

function test1() {
    const map = new Map([
        ['map', 'карта'],
        ['list', 'список'],
        ['function', 'функция'],
        ['promise', 'обещание'],
        ['promise', 'промис'],
    ])
    console.log(map)
}

function test1() {
    const map = new Map([
        ['map', 'карта'],
        ['list', 'список'],
        ['function', 'функция'],
    ])
    // for (const item of map) {
    //     console.log(item)
    // }
    // for (const [key, val] of map) {
    //     console.log(key, val)
    // }
    // for (const key of map.keys()) {
    //     console.log(key)
    // }
    for (const value of map.values()) {
        console.log(value)
    }
}

function test1() {
    const map = new Map([
        ['map', 'карта'],
        ['list', 'список'],
        ['function', 'функция'],
    ])
    console.log(map.get('list'))
}

function test() {
    const map = new Map([
        ['map', 'карта'],
        ['list', 'список'],
        ['function', 'функция'],
    ])
    map.delete('function')
    console.log(map)
    console.log(map.size)
}

test()
