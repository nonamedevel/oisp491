function test() {
    const res = {
        key1: 'value 1',
        key2: 'value 2',
        statusCode: 200
    }
    console.log(res.statusCode)

    const { statusCode } = res
    console.log(statusCode)
}

test()
