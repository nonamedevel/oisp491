function test1() {
    function example() {
        console.log(this)
    }
    example()
}

function test1() {
    function example() {
        console.log(this)
    }
    example.call({num: 123})
    example.apply({num: 456})
}

function test() {
    class User {
        constructor(name, age, premium) {
            this.name = name
            this.age = age
            this.premium = premium
            console.log(this)
        }
    }
    const user = new User('Vasya', 25, false)
}

test()
