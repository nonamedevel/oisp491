function test() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
        'dark-blue': 'темно-синий',
    }
    
    // console.log(colors.red)
    // console.log(colors['dark-blue'])
    // console.log(colors['orange'])

    console.log(colors.red !== undefined)
    console.log(colors['dark-blue'] !== undefined)
    console.log(colors['orange'] !== undefined)
}

function test1() {
    const colors = {}
    colors['red'] = 'красный'
    colors['green'] = 'зеленый'
    colors['blue'] = 'синий'
    colors['dark-blue'] = 'темно-синий'
    console.log(colors)
}

function test1() {
    const colors = {}
    let colorName
    colorName = 'red'
    colors[colorName] = 'красный'
    colorName = 'green'
    colors[colorName] = 'зеленый'
    colorName = 'blue'
    colors[colorName] = 'синий'
    colorName = 'dark-blue'
    colors[colorName] = 'темно-синий'
    console.log(colors)
}

function test1() {
    const colors = {
        red: function() {
            console.log('красный')
        },
        green: function() {
            console.log('зеленый')
        },
        blue: function() {
            console.log('синий')
        },
        'dark-blue': function() {
            console.log('темно-синий')
        },
    }
    if (colors.red) {
        colors.red()
    }
    if (colors.black) {
        colors.black()
    }
    if (colors['dark-blue']) {
        colors['dark-blue']()
    }
}

test()
