function test1() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
        'dark-blue': 'темно-синий',
    }
    console.log(colors.red)
    console.log(colors['dark-blue'])
}

function test() {
    const colors = {
        red: function() {
            console.log('красный')
        },
        green: function() {
            console.log('зеленый')
        },
        blue: function() {
            console.log('синий')
        },
        'dark-blue': function() {
            console.log('темно-синий')
        },
    }
    if (colors.red) {
        colors.red()
    }
    if (colors.black) {
        colors.black()
    }
    if (colors['dark-blue']) {
        colors['dark-blue']()
    }
}

test()
