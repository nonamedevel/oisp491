function test() {
    function example() {
        console.log(this)
    }
    example()
    // const boundExample = example.bind({num: 333})
    // boundExample()
}

test()
