const grid = [
    0, 1, 0, 1, 0,
    1, 0, 0, 0, 1,
    1, 0, 0, 0, 1,
    1, 0, 0, 0, 1,
    1, 0, 0, 0, 1,
    1, 0, 0, 0, 1,
    1, 0, 0, 0, 1,
    0, 0, 0, 0, 1,
    0, 0, 0, 1, 0,
]

function test() {
    function countOnes() {
        let counter = 0
        for (let i = 0; i < grid.length; i++) {
            if (grid[i] === 1){
                counter += 1
            }
        }
        return counter
    } 
    console.log(countOnes())
}



test()
