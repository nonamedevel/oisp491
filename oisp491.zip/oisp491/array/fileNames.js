const fileNames = [
    'file2.css',
    'file5.js',
    'file4',
    'file7.js',
    'file6.js',
    'file3.css',
    'file1.css',
    'file8.js',
]

function test1() {
    const cssList = []
    const jsList = []
    const stringList = []
    for (let i = 0; i<fileNames.length; i++) {
        let fileExtension = fileNames[i].split(".")[1]
        if (fileExtension === 'css') {
            cssList.push(fileNames[i])
        } else if (fileExtension === 'js') {
            jsList.push(fileNames[i])
        } else {
            stringList.push(fileNames[i])
        }
    }
   console.log(cssList, jsList, stringList) 
}

function test() {
    const cssList = []
    const jsList = []
    const stringList = []
    for (const fileName of fileNames) {
        let fileExtension = fileName.split(".")[1]
        if (fileExtension === 'css') {
            cssList.push(fileName)
        } else if (fileExtension === 'js') {
            jsList.push(fileName)
        } else {
            stringList.push(fileName)
        }
    }
    console.log(cssList, jsList, stringList)
}

test()
