function test() {
    const arr = ['apple', 'orange', 'kiwi']
    // console.log(arr[0])
    // console.log(arr[1])
    // console.log(arr[2])

    const [fruit1, fruit2, fruit3] = arr
    console.log(fruit1)
    console.log(fruit2)
    console.log(fruit3)
}

test()
