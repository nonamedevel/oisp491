function test1() {
    const user1 = {
        name: 'Vasya',
        age: 20,
        premium: false,
    }
    const user2 = {
        name: 'Masha',
        age: 30,
        premium: true,
    }
    const user3 = {
        name: 'User',
        age: 99,
        premium: false,
    }
    if (user1.premium) {
        console.log(user1.name)
    }
    if (user2.premium) {
        console.log(user2.name)
    }
    if (user3.premium) {
        console.log(user3.name)
    }
}

function test() {
    const user1 = {
        name: 'Vasya',
        age: 20,
        premium: false,
    }
    const user2 = {
        name: 'Masha',
        age: 30,
        premium: true,
    }
    const user3 = {
        name: 'User',
        age: 99,
        premium: false,
    }
    function printUserName(user) {
        if (user.premium) {
            console.log(user.name)
        }
    }
    printUserName(user1) // user = user1
    printUserName(user2) // user = user2
    printUserName(user3) // user = user3
}

function test1() {
    const users = [
        {
            name: 'Vasya',
            age: 20,
            premium: false,
        },
        {
            name: 'Masha',
            age: 30,
            premium: true,
        },
        {
            name: 'User',
            age: 99,
            premium: false,
        },
        {
            name: 'User5',
            age: 99,
            premium: true,
        },
    ]
    for (const user of users) {
        if (user.premium) {
            console.log(user.name)
        }
    }
}

function test() {
    const users = [
        {
            name: 'Vasya',
            age: 20,
            premium: false,
        },
        {
            name: 'Masha',
            age: 32,
            premium: true,
        },
        {
            name: 'User',
            age: 99,
            premium: false,
        },
    ]
    console.log(users[2].age)
}

test()