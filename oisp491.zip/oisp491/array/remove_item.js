function test1() {
    const fruits = ['apple', 'orange', 'banana', 'pear', 'mango']
    console.log(fruits)
    fruits.pop()
    console.log(fruits)
}

function test1() {
    let fruits = ['apple', 'orange', 'banana', 'pear', 'mango']
    console.log(fruits)

    const tempArr = []
    for (let i = 0; i < fruits.length; i++) {
        if (fruits[i] !== 'orange') {
            tempArr.push(fruits[i])
        }
    }
    fruits = tempArr
    console.log(fruits)
}

function test1() {
    let fruits = ['apple', 'orange', 'banana', 'pear', 'mango']
    console.log(fruits)

    for (let i = 0; i < fruits.length; i++) {
        if (fruits[i] === 'orange') {
            fruits[i] = null
            break
        }
    }
    console.log(fruits)
}

function test() {
    let fruits = ['apple', 'orange', 'banana', 'pear', 'mango']
    console.log(fruits)

    function removeItem(item) {
        for (let i = 0; i < fruits.length; i++) {
            if (fruits[i] === item) {
                fruits[i] = null
                break
            }
        }
    }
    function addItem(item) {
        fruits.push(item)
    }
    function vacuum() {
        const tempArr = []
        for (let i = 0; i < fruits.length; i++) {
            if (fruits[i] !== null) {
                tempArr.push(fruits[i])
            }
        }
        fruits = tempArr
    }

    removeItem('orange')
    addItem('kiwi')
    addItem('strawberry')
    addItem('blueberry')
    addItem('water-melon')
    addItem('melon')
    addItem('cherry')
    removeItem('apple')
    removeItem('banana')
    removeItem('kiwi')
    addItem('grape')
    removeItem('melon')
    removeItem('cherry')
    removeItem('pear')
    removeItem('strawberry')
    console.log(fruits)

    vacuum()
    console.log(fruits)
}

test()
