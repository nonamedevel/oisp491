
function test() {
    const users = [
        'Vasya',
        'Masha',
        'User',
    ]
    console.log(users.length)
    users.push('User123')
    console.log(users.length)
}

test()
