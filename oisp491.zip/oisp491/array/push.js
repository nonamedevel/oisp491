
function test() {
    const users = []
    console.log(users)
    users.push({
        name: 'Vasya',
        age: 20,
        premium: false,
    })
    console.log(users)
    users.push({
        name: 'Masha',
        age: 32,
        premium: true,
    })
    console.log(users)
    users.push({
        name: 'User',
        age: 99,
        premium: false,
    })
    console.log(users)
}

test()
