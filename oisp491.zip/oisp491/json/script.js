const users = [
    {
        id: 1,
        name: 'John',
        premium: true,
        data: [345, 363, 142],
    },
    {
        id: 2,
        name: 'Jane',
        premium: false,
        data: [31, 95, 869, 341],
    },
    {
        id: 3,
        name: 'Vasya',
        premium: false,
        data: null,
    },
]

// const usersStr = JSON.stringify(users)
const usersStr = JSON.stringify(users, null, 2)
console.log(usersStr)


const usersStr2 = `[
  {
    "id": 1,
    "name": "John",
    "premium": true,
    "data": [
      345,
      363,
      142
    ]
  },
  {
    "id": 2,
    "name": "Jane",
    "premium": false,
    "data": [
      31,
      95,
      869,
      341
    ]
  },
  {
    "id": 3,
    "name": "Vasya",
    "premium": false,
    "data": null
  }
]`

const usersStr3 = JSON.parse(usersStr2)
console.log(usersStr3)