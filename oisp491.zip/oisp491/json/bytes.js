function test1() {
    const str = '{"a": 5}'
    const obj = JSON.parse(str)
    console.log(obj)
    console.log(str.split('').map(x => x.charCodeAt()))
}

function test1() {
    const bytes = [123, 34, 97, 34, 58, 32, 53, 125]
    const obj = JSON.parse(bytes.map(x => String.fromCharCode(x)).join(''))
    console.log(obj)
}

function test() {
    const bytes = [123, 13, 10, 32, 32, 32, 32, 34, 101, 100, 105, 116, 111, 114, 46, 109, 105, 110, 105, 109, 97, 112, 46, 101, 110, 97, 98, 108, 101, 100, 34, 58, 32, 102, 97, 108, 115, 101, 44, 13, 10, 32, 32, 32, 32, 34, 119, 105, 110, 100, 111, 119, 46, 109, 101, 110, 117, 66, 97, 114, 86, 105, 115, 105, 98, 105, 108, 105, 116, 121, 34, 58, 32, 34, 99, 108, 97, 115, 115, 105, 99, 34, 13, 10, 125]
    const obj = JSON.parse(bytes.map(x => String.fromCharCode(x)).join(''))
    console.log(obj)
}

test()
